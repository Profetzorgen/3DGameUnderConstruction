//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class Attributes : MonoBehaviour
//{
//    public enum Attributes  // Ej f�rdigt men s�h�r kan man anv�nda sig av Enum f�r att hantera
//        // powerups s� som health potions eller sprint-dricka etc.
//    {
//        Attack,
//        MovementSpeed,
//        CurrentHealth,
//        MaxHealth
//    }
//}
