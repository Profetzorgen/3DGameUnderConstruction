//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//[
//    RequireComponent(typeof(Collider)),  // EJ f�rdig, powerup-relaterat
//    RequireComponent(typeof(Rigidbody))

//]
//public abstract class Powerup : MonoBehaviour
//{
//    [SerializeField] private Attributes attributes;

//    public Attributes Attribute
//    {
//        get { return attributes; }

//    }
//    public void Consume()
//    {
//        Destroy(gameObject); // Detta tar bort objektet, exempelvis via att man g�r in i ett hj�rta och d� f�r man x % HP
//        // Kan �ven aktiveras manuellt om det �r s� att man plockar upp potions och vill anv�nda bara n�r det beh�vs
//    }
//}
